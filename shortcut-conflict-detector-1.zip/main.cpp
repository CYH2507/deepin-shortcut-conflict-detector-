#include "conflict_detector.h"

#include <DApplication>
#include <DMainWindow>
#include <DWidget>
#include <DListView>
#include <DPushButton>
#include <DLabel>
#include <DToast>

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QStandardItemModel>
#include <QFont>
#include <QColor>
#include <QTimer>

DWIDGET_USE_NAMESPACE

int main(int argc, char *argv[])
{
    DApplication app(argc, argv);
    app.setOrganizationName("deepin");
    app.setApplicationName("shortcut-conflict-detector");
    app.setApplicationVersion("1.0.0");

    DMainWindow window;
    window.setWindowTitle(QStringLiteral("快捷键冲突检测"));
    window.resize(760, 540);

    auto *central = new DWidget(&window);
    window.setCentralWidget(central);

    auto *vlay = new QVBoxLayout(central);
    vlay->setContentsMargins(24, 24, 24, 24);
    vlay->setSpacing(14);

    // 页面标题
    auto *titleLabel = new DLabel(QStringLiteral("快捷键冲突检测"), central);
    QFont tf = titleLabel->font();
    tf.setPixelSize(22);
    tf.setBold(true);
    titleLabel->setFont(tf);
    vlay->addWidget(titleLabel);

    // 冲突列表
    auto *listView = new DListView(central);
    listView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    listView->setSelectionMode(QAbstractItemView::NoSelection);
    auto *model = new QStandardItemModel(listView);
    listView->setModel(model);
    vlay->addWidget(listView, 1);

    // 无冲突提示（绿色）
    auto *okLabel = new DLabel(QStringLiteral("未发现快捷键冲突"), central);
    okLabel->setStyleSheet("color: #2ec946; font-size: 18px;");
    okLabel->setAlignment(Qt::AlignCenter);
    okLabel->hide();
    vlay->addWidget(okLabel);

    // 错误提示（红色）
    auto *errorLabel = new DLabel(central);
    errorLabel->setStyleSheet("color: #d32f2f; font-size: 15px;");
    errorLabel->setWordWrap(true);
    errorLabel->setAlignment(Qt::AlignCenter);
    errorLabel->hide();
    vlay->addWidget(errorLabel);

    // Toast 提示
    auto *toast = new DToast(&window);

    // 底部刷新按钮
    auto *hlay = new QHBoxLayout();
    hlay->addStretch();
    auto *refreshBtn = new DPushButton(QStringLiteral("刷新"), central);
    refreshBtn->setFixedWidth(140);
    hlay->addWidget(refreshBtn);
    vlay->addLayout(hlay);

    // 检测并刷新界面
    auto doDetect = [&]() {
        model->clear();
        listView->hide();
        okLabel->hide();
        errorLabel->hide();

        ConflictDetector detector;
        const QList<ShortcutItem> conflicts = detector.detect();

        if (!detector.lastError().isEmpty()) {
            errorLabel->setText(
                QStringLiteral("无法获取系统快捷键\n") + detector.lastError());
            errorLabel->show();
            return;
        }

        if (conflicts.isEmpty()) {
            okLabel->show();
            return;
        }

        for (const auto &item : conflicts) {
            const QString text = QString("%1  |  %2  |  %3")
                .arg(item.shortcut, item.systemAction, item.appAction);
            auto *row = new QStandardItem(text);
            if (item.conflict) {
                row->setForeground(QColor("#d32f2f")); // 冲突行红色高亮
                QFont rf = row->font();
                rf.setBold(true);
                row->setFont(rf);
            }
            model->appendRow(row);
        }
        listView->show();
    };

    QObject::connect(refreshBtn, &DPushButton::clicked, [&]() {
        doDetect();
        toast->setText(QStringLiteral("已重新检测"));
        toast->adjustSize();
        toast->move((window.width() - toast->width()) / 2, window.height() - 120);
        toast->show();
        QTimer::singleShot(2000, toast, &QWidget::hide);
    });

    // 启动时自动检测一次
    doDetect();

    window.show();
    return app.exec();
}

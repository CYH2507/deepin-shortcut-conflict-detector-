# 快捷键冲突检测

基于 DDE 控制中心风格的独立插件，用于检测系统全局快捷键与 VSCode 快捷键之间的冲突。

## 功能

- 通过 D-Bus 调用 `org.deepin.dde.Keybinding1` 获取系统全局快捷键（快捷键组合 + 功能名称）
- 读取 `~/.config/Code/User/keybindings.json`（VSCode 快捷键），文件不存在则静默跳过
- 比对系统快捷键与软件快捷键，找出相同快捷键组合（冲突项）
- UI 展示：
  - 有冲突：用 `DListView` 展示列表，每行显示「快捷键组合 | 系统功能 | 软件功能」，冲突行红色高亮
  - 无冲突：显示绿色文字「未发现快捷键冲突」
  - 底部「刷新」按钮，点击重新检测
- D-Bus 调用失败时显示「无法获取系统快捷键」提示，不崩溃

## 技术说明

- 使用 DTK 控件：`DWidget`、`DListView`、`DPushButton`、`DLabel`、`DToast`
- 所有文件读取和 D-Bus 调用均做异常保护（返回值检查）
- 插件以独立进程运行，崩溃不影响 DDE 控制中心
- 兼容 Qt5 / Qt6 与 dtkwidget / dtk6widget（适配 deepin 25）

## 依赖

deepin 25 上安装：

```bash
sudo apt install cmake g++ pkg-config libdtkwidget-dev qtbase5-dev
```

> 若使用 Qt6/DTK6，安装对应的 `qt6-base-dev`、`libdtkwidget6-dev`。

## 编译

```bash
mkdir build && cd build
cmake ..
make
sudo make install
```

## 运行

```bash
shortcut-conflict-detector
```

## 目录结构

```
.
├── CMakeLists.txt
├── README.md
└── src
    ├── conflict_detector.cpp   # 冲突检测逻辑（D-Bus + 文件解析 + 比对）
    ├── conflict_detector.h
    └── plugin_main.cpp         # 插件入口 + UI 布局
```

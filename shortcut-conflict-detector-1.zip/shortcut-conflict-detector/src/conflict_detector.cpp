#include "conflict_detector.h"

#include <QDBusInterface>
#include <QDBusReply>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDir>

ConflictDetector::ConflictDetector(QObject *parent)
    : QObject(parent)
{
}

// 统一快捷键格式用于比对：
// GTK accel "<Ctrl><Shift>p"  ->  "ctrl+shift+p"
// VSCode     "ctrl+shift+p"   ->  "ctrl+shift+p"
QString ConflictDetector::normalizeShortcut(const QString &shortcut)
{
    QString s = shortcut.trimmed();
    if (s.isEmpty())
        return s;

    // GTK accel 格式：<Ctrl><Shift>p —— 把 < > 当作分隔符
    if (s.contains('<') || s.contains('>')) {
        s.replace("<", "+");
        s.replace(">", "+");
    }

    // Primary / Control 统一为 Ctrl
    s.replace("Primary", "Ctrl", Qt::CaseInsensitive);
    s.replace("Control", "Ctrl", Qt::CaseInsensitive);

    // 统一分隔符：连字符、空格 -> +
    s.replace("-", "+");
    s.replace(" ", "+");

    // 合并连续 + 并去除首尾 +
    while (s.contains("++"))
        s.replace("++", "+");
    while (s.startsWith("+"))
        s = s.mid(1);
    while (s.endsWith("+"))
        s.chop(1);

    return s.toLower();
}

// 生成显示用快捷键：ctrl+shift+p -> Ctrl+Shift+P
QString ConflictDetector::displayShortcut(const QString &shortcut)
{
    const QString n = normalizeShortcut(shortcut);
    if (n.isEmpty())
        return QString();

    QStringList parts = n.split('+', Qt::SkipEmptyParts);
    for (auto &p : parts) {
        if (p == "ctrl")           p = "Ctrl";
        else if (p == "shift")     p = "Shift";
        else if (p == "alt")       p = "Alt";
        else if (p == "super" || p == "meta") p = "Super";
        else                       p = p.toUpper();
    }
    return parts.join('+');
}

bool ConflictDetector::fetchSystemShortcuts(QMap<QString, QString> &out)
{
    QDBusInterface iface("org.deepin.dde.Keybinding1",
                         "/org/deepin/dde/Keybinding1",
                         "org.deepin.dde.Keybinding1",
                         QDBusConnection::sessionBus());
    if (!iface.isValid()) {
        m_lastError = QStringLiteral("无法连接到 Keybinding1 D-Bus 服务");
        return false;
    }

    QDBusReply<QString> reply = iface.call("ListAllShortcuts");
    if (!reply.isValid()) {
        m_lastError = QStringLiteral("D-Bus 调用 ListAllShortcuts 失败：")
                      + reply.error().message();
        return false;
    }

    const QByteArray raw = reply.value().toUtf8();
    QJsonParseError parseErr;
    QJsonDocument doc = QJsonDocument::fromJson(raw, &parseErr);
    if (parseErr.error != QJsonParseError::NoError) {
        m_lastError = QStringLiteral("解析系统快捷键 JSON 失败");
        return false;
    }

    // 兼容数组或包裹在对象中的数组
    QJsonArray arr;
    if (doc.isArray()) {
        arr = doc.array();
    } else if (doc.isObject()) {
        const QJsonObject obj = doc.object();
        for (const auto &k : obj.keys()) {
            if (obj.value(k).isArray()) {
                arr = obj.value(k).toArray();
                break;
            }
        }
    }

    for (const auto &val : arr) {
        const QJsonObject item = val.toObject();
        QString accel = item.value("Accel").toString();
        if (accel.isEmpty())
            accel = item.value("accel").toString();
        if (accel.isEmpty())
            continue;

        QString action = item.value("Action").toString();
        if (action.isEmpty())
            action = item.value("Description").toString();
        if (action.isEmpty())
            action = item.value("Name").toString();
        if (action.isEmpty())
            action = accel;

        const QString key = normalizeShortcut(accel);
        if (!key.isEmpty())
            out.insert(key, action);
    }
    return true;
}

bool ConflictDetector::fetchVSCodeShortcuts(QMap<QString, QString> &out)
{
    const QString path = QDir::homePath() + "/.config/Code/User/keybindings.json";
    const QFileInfo info(path);
    // 文件不存在则静默跳过，不报错
    if (!info.exists() || !info.isFile())
        return true;

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
        return true; // 读失败也跳过

    QString raw = QString::fromUtf8(file.readAll());
    file.close();

    // VSCode keybindings.json 允许 // 注释，先去除再解析
    QJsonParseError parseErr;
    QJsonDocument doc = QJsonDocument::fromJson(raw.toUtf8(), &parseErr);
    if (parseErr.error != QJsonParseError::NoError || !doc.isArray()) {
        QStringList lines = raw.split('\n');
        QStringList cleaned;
        cleaned.reserve(lines.size());
        for (const auto &l : lines) {
            int idx = l.indexOf("//");
            cleaned << (idx >= 0 ? l.left(idx) : l);
        }
        doc = QJsonDocument::fromJson(cleaned.join('\n').toUtf8(), &parseErr);
        if (parseErr.error != QJsonParseError::NoError || !doc.isArray())
            return true; // 解析失败跳过，不报错
    }

    const QJsonArray arr = doc.array();
    for (const auto &val : arr) {
        const QJsonObject item = val.toObject();
        const QString key = item.value("key").toString();
        if (key.isEmpty())
            continue;
        const QString command = item.value("command").toString();
        const QString normalized = normalizeShortcut(key);
        if (!normalized.isEmpty())
            out.insert(normalized, command);
    }
    return true;
}

QList<ShortcutItem> ConflictDetector::detect()
{
    m_lastError.clear();
    QList<ShortcutItem> result;

    QMap<QString, QString> systemShortcuts;
    if (!fetchSystemShortcuts(systemShortcuts)) {
        // 错误信息已写入 m_lastError
        return result;
    }

    QMap<QString, QString> appShortcuts;
    fetchVSCodeShortcuts(appShortcuts);

    // 比对：系统与软件相同快捷键即为冲突
    for (auto it = systemShortcuts.constBegin(); it != systemShortcuts.constEnd(); ++it) {
        const QString &key = it.key();
        if (appShortcuts.contains(key)) {
            ShortcutItem item;
            item.shortcut     = displayShortcut(key);
            item.systemAction = it.value();
            item.appAction    = appShortcuts.value(key);
            item.conflict     = true;
            result.append(item);
        }
    }
    return result;
}

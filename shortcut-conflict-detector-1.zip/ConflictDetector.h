#ifndef CONFLICTDETECTOR_H
#define CONFLICTDETECTOR_H

#include <QObject>
#include <QString>
#include <QList>
#include <QMap>

// 单条快捷键比对结果
struct ShortcutItem {
    QString shortcut;      // 显示用快捷键组合，如 "Ctrl+Shift+P"
    QString systemAction;  // 系统功能名称
    QString appAction;     // 软件功能名称
    bool conflict;         // 是否冲突
};

// 快捷键冲突检测器
// 负责：D-Bus 获取系统快捷键、读取 VSCode 快捷键、比对冲突
class ConflictDetector : public QObject
{
    Q_OBJECT
public:
    explicit ConflictDetector(QObject *parent = nullptr);

    // 执行检测，返回冲突列表（仅返回冲突项）
    QList<ShortcutItem> detect();

    // 上次检测的错误信息（如 D-Bus 失败），为空表示无错误
    QString lastError() const { return m_lastError; }

private:
    // 通过 D-Bus 获取系统全局快捷键，成功返回 true
    bool fetchSystemShortcuts(QMap<QString, QString> &out);
    // 读取 VSCode keybindings.json，文件不存在则静默跳过
    bool fetchVSCodeShortcuts(QMap<QString, QString> &out);

    // 规范化快捷键用于比对（统一小写、统一分隔符）
    static QString normalizeShortcut(const QString &shortcut);
    // 生成显示用快捷键（首字母大写）
    static QString displayShortcut(const QString &shortcut);

    QString m_lastError;
};

#endif // CONFLICTDETECTOR_H

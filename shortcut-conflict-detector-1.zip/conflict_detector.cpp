#include "conflict_detector.h"

#include <QDBusInterface>
#include <QDBusReply>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDir>

ConflictDetector::ConflictDetector(QObject *parent)
    : QObject(parent)
{
}

// 统一快捷键格式用于比对：
// GTK accel "<Ctrl><Shift>p"  ->  "ctrl+shift+p"
// VSCode     "ctrl+shift+p"   ->  "ctrl+shift+p"
QString ConflictDetector::normalizeShortcut(const QString &shortcut)
{
    QString s = shortcut.trimmed();
    if (s.isEmpty())
        return s;

    // 处理 GTK accel 格式：<Ctrl><Shift>p
    s.replace("><", "+");
    s.remove('<');
    s.remove('>');

    // Primary / Control 统一为 Ctrl
    s.replace("Primary", "Ctrl", Qt::CaseInsensitive);
    s.replace("Control", "Ctrl", Qt::CaseInsensitive);

    // 统一分隔符
    s.replace("-", "+");
    s.remove(' ');

    return s.toLower();
}

// 生成显示用快捷键：ctrl+shift+p -> Ctrl+Shift+P
QString ConflictDetector::displayShortcut(const QString &shortcut)
{
    const QString n = normalizeShortcut(shortcut);
    if (n.isEmpty())
        return QString();

    QStringList parts = n.split('+', Qt::SkipEmptyParts);
    for (auto &p : parts) {
        if (p == "ctrl")           p = "Ctrl";
        else if (p == "shift")     p = "Shift";
        else if (p == "alt")       p = "Alt";
        else if (p == "super" || p == "meta") p = "Super";
        else                       p = p.toUpper();
    }
    return parts.join('+');
}

bool ConflictDetector::fetchSystemShortcuts(QMap<QString, QString> &out)
{
    QDBusInterface iface("org.deepin.dde.Keybinding1",
                         "/org/deepin/dde/Keybinding1",
                         "org.deepin.dde.Keybinding1",
                         QDBusConnection::sessionBus());
    if (!iface.isValid()) {
        m_lastError = QStringLiteral("无法连接到 Keybinding1 D-Bus 服务");
        return false;
    }

    QDBusReply<QString> reply = iface.call("ListAllShortcuts");
    if (!reply.isValid()) {
        m_lastError = QStringLiteral("D-Bus 调用 ListAllShortcuts 失败：")
                      + reply.error().message();
        return false;
    }

    const QByteArray raw = reply.value().toUtf8();
    QJsonParseError parseErr;
    QJsonDocument doc = QJsonDocument::fromJson(raw, &parseErr);
    if (parseErr.error != QJsonParseError::NoError) {
        m_lastError = QStringLiteral("解析系统快捷键 JSON 失败");
        return false;
    }

    // 兼容数组或包裹在对象中的数组
    QJsonArray arr;
    if (doc.isArray()) {
        arr = doc.array();
    } else if (doc.isObject()) {
        const QJsonObject obj = doc.object();
        for (const auto &k : obj.keys()) {
            if (obj.value(k).isArray()) {
                arr = obj.value(k).toArray();
                break;
            }
        }
    }

    for (const auto &val : arr) {
        const QJsonObject item = val.toObject();
        QString accel = item.value("Accel").toString();
        if (accel.isEmpty())
            accel = item.value("accel").toString();
        if (accel.isEmpty())
            continue;

        QString action = item.value("Action").toString();
        if (action.isEmpty())
            action = item.value("Description").toString();
        if (action.isEmpty())
            action = item.value("Name").toString();
        if (action.isEmpty())
            action = accel;

        const QString key = normalizeShortcut(accel);
        if (!key.isEmpty())
            out.insert(key, action);
    }
    return true;
}

bool ConflictDetector::fetchVSCodeShortcuts(QMap<QString, QString> &out)
{
    const QString path = QDir::homePath() + "/.config/Code/User/keybindings.json";
    const QFileInfo info(path);
    // 文件不存在则静默跳过，不报错
    if (!info.exists() || !info.isFile())
        return true;

    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
        return true; // 读失败也跳过

    QString raw = QString::fromUtf8(file.readAll());
    file.close();

    // VSCode keybindings.json 允许 // 注释，先去除再解析
    QJsonParseError parseErr;
    QJsonDocument doc = QJsonDocument::fromJson(raw.toUtf8(), &parseErr);
    if (parseErr.error != QJsonParseError::NoError || !doc.isArray()) {
        QStringList lines = raw.split('\n');
        QStringList cleaned;
        cleaned.reserve(lines.size());
        for (const auto &l : lines) {
            int idx = l.indexOf("//");
            cleaned << (idx >= 0 ? l.left(idx) : l);
        }
        doc = QJsonDocument::fromJson(cleaned.join('\n').toUtf8(), &parseErr);
        if (parseErr.error != QJsonParseError::NoError || !doc.isArray())
            return true; // 解析失败跳过，不报错
    }

    const QJsonArray arr = doc.array();
    for (const auto &val : arr) {
        const QJsonObject item = val.toObject();
        const QString key = item.value("key").toString();
        if (key.isEmpty())
            continue;
        const QString command = item.value("command").toString();
        const QString normalized = normalizeShortcut(key);
        if (!normalized.isEmpty())
            out.insert(normalized, command);
    }
    return true;
}

QList<ShortcutItem> ConflictDetector::detect()
{
    QList<ShortcutItem> result;
    m_lastError.clear();

    QMap<QString, QString> systemMap;
    QMap<QString, QString> vscodeMap;

    if (!fetchSystemShortcuts(systemMap)) {
        // 错误已写入 m_lastError，返回空列表
        return result;
    }

    // VSCode 读取失败/不存在不视为错误，仅跳过
    fetchVSCodeShortcuts(vscodeMap);

    // 比对：以系统快捷键为基准，检查是否被 VSCode 占用
    for (auto it = systemMap.constBegin(); it != systemMap.constEnd(); ++it) {
        const QString &shortcutKey = it.key();
        const QString &systemAction = it.value();

        ShortcutItem item;
        item.shortcut = displayShortcut(shortcutKey);
        item.systemAction = systemAction;
        item.conflict = vscodeMap.contains(shortcutKey);
        item.appAction = item.conflict ? vscodeMap.value(shortcutKey) : QString();
        result.append(item);
    }

    // 再检查 VSCode 中未在系统里出现的项（补充完整性）
    for (auto it = vscodeMap.constBegin(); it != vscodeMap.constEnd(); ++it) {
        if (!systemMap.contains(it.key())) {
            ShortcutItem item;
            item.shortcut = displayShortcut(it.key());
            item.systemAction = QString();
            item.appAction = it.value();
            item.conflict = false;
            result.append(item);
        }
    }

    return result;
}
